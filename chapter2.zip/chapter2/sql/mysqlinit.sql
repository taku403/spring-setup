CREATE DATABASE spring;
GRANT ALL PRIVILEGES ON spring.* to springuser@localhost IDENTIFIED BY 'springpassword' WITH GRANT OPTION;
quit