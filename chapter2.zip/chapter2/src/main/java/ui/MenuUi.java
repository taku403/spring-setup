package ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MenuUi extends AbstractUiTemplate {

    private SelectTeamUi selectTeamUi;

    public void setSelectTeamUi(SelectTeamUi selectTeamUi) {
        this.selectTeamUi = selectTeamUi;
    }

    protected void showMenu() {
        System.out.println("--------------------");
        System.out.println("選手");
        System.out.println("");
        System.out.println("1. 終了");
        System.out.println("2. チーム一覧");
        System.out.println("");
        System.out.println("番号入力し、Enterを押してください");
    }

    protected int getMaxMenuNumber() {
        return 2;
    }

    protected int getMinMenuNumber() {
        return 1;
    }

    protected void execute(int number) {
        switch (number) {
        case 1:
            System.out.println("終了");
            System.exit(0);
        case 2:
            this.selectTeamUi.show();
            break;
        }
    }

    public static void main(String[] args) {
        @SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        System.out.println("test");
        MenuUi menuUi = context.getBean(MenuUi.class);
        while (true) {
            menuUi.show();
        }
    }
}
