package ui;

import org.springframework.util.NumberUtils;
import org.springframework.util.StringUtils;

public abstract class AbstractUiTemplate extends AbstractUi {

    public void show() {
        showMenu();
        String inputedString = getInputedString();
        if (isValidNumber(inputedString)) {
            execute(NumberUtils.parseNumber(inputedString, Integer.class));
        }
    }

    abstract protected void showMenu();

    abstract protected int getMaxMenuNumber();

    abstract protected int getMinMenuNumber();

    abstract protected void execute(int number);

    protected boolean isValidNumber(String str) {

        if (StringUtils.isEmpty(str)) {
            return false;
        } else if (!isNumber(str)) {
            return false;
        }
        int number = NumberUtils.parseNumber(str, Integer.class);
        if (getMinMenuNumber() <= number && number <= getMaxMenuNumber()) {
            return true;
        }
        return false;
    }

    private boolean isNumber(String str) {
    	for(int i = 0; i < str.length(); i++) {
    		if(!Character.isDigit(str.charAt(i))) {
    			return false;
    		}
    	}
    	return true;
    }
}
