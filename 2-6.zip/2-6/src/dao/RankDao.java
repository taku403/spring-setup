package dao;

import java.util.List;

public interface RankDao {

    List<Object[]> getRank(Integer eventId);

}
